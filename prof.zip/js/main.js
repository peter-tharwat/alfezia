$('.toggle-aside').on('click', function() {
    $('.content-container').toggleClass('aside');
});
$('#change-mood').on('click',function(){
	$('body').toggleClass('dark');
});